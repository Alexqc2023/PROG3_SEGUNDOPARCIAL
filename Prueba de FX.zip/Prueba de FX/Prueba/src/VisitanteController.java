import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class VisitanteController {

    

    @FXML
    private Button bntNuevoTi;

    @FXML
    private Button btnAgregarVi;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button btnGuardar;

    @FXML
    private Button btnLimpiar;

    @FXML
    private ComboBox<Visitante> lblTipo;

    @FXML
    private TextField txtNombre;

    @FXML
    void Agregar(ActionEvent event) {

        btnAgregarVi.accessibleTextProperty().addListener(btnAgregarVi);
        Platform.runLater((Runnable) btnAgregarVi);
        


        if (txtNombre.getText().isEmpty() || btnAgregarVi.getText().isEmpty()  ){



        }

            
        Alert alerta = new Alert(AlertType.WARNING);
        Alert alerta = alerta ("Por favor completa la informacion");
        alerta = new Alert("Por favor pon alguna informacion al menos");

        

        

        try {

        if (btnAgregarVi == null){


        }

        
        
            



            
        } catch (Exception e) {


            if ( btnAgregarVi != null) {
                
            }


            Alert funciona = new Alert(AlertType.CONFIRMATION);
            Alert Funciona = (" el boton agrega de forma correcta");

            


            
            
        }



        

    }

    @FXML
    void AgregarTipo(ActionEvent event) {


        

        ObservableList<Visitante>AgregarTipo = new ObservableList;

        try {
            
            Alert alerta = new Alert(AlertType.WARNING);
            
        } catch (Exception e) {

            Alert aviso = new Alert(AlertType.CONFIRMATION);
            
        }

    }

    @FXML
    void Eliminar(ActionEvent event) {

       btnEliminar.accessibleRoleProperty().addListener(null);



       Alert alerta = new Alert(AlertType.WARNING);

        try {
            
        } catch (Exception e) {

            Alert aviso = new Alert(AlertType.CONFIRMATION);
            
        }


    }

    @FXML
    void Guardar(ActionEvent event) {

        btnGuardar.accessibleRoleProperty().addListener(null);

        Alert alerta = new Alert(AlertType.WARNING);

        try {

            Thread Hilo = new Thread () ->{


                Platform.runLater(Hilo);






            }
            
        } catch (Exception e) {

            Alert aviso = new Alert(AlertType.CONFIRMATION);
            
        }

    }

    @FXML
    void Limpiar(ActionEvent event) {

        btnLimpiar.accessibleRoleProperty().addListener(null);

        

        try {

            if ( btnLimpiar == null) {


                
            }
            
        } catch (Exception e) {
            

            Alert funciona = new Alert(AlertType.CONFIRMATION);
            Alert funciona = ("La informacion fue resivida");
           

        }

    }

}

