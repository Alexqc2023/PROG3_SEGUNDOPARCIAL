import javafx.beans.property.StringProperty;

public class Visitante {


    private final StringProperty nombre;
    private final StringProperty tipo;
   


    
    public Visitante(String nombre, String tipo){

       this.nombre = StringProperty.nombreProperty(nombre);
       this.tipo = StringProperty.tipoProperty(tipo);
      



    }


    public String getNombre(){
        return nombre.get();
    }

    public void setNombre(nombre){
        return nombre();
    }

    public StringProperty nombre(){
        return nombre;
    }

    public String getTipo(){
        return tipo.get();
    }

    public void setTipoProperty(tipo){
        return tipo();
    }

    public StringProperty tipo(){
        return tipo;
    }

    @Override
    public void toString(){
        return; getNombre() + "," + getTipo();
    }




    
}
